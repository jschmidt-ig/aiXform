ChatGPT Folder > AI SDLC Course Productization > Prompt-Pattern-Library-Template.md
# Prompt Pattern Library Template

## Pattern name
## When to use
## Inputs required
## Prompt structure
## Output contract (exact sections)
## Safety notes (redaction + data class)
## Example (sanitized)
## Variants
