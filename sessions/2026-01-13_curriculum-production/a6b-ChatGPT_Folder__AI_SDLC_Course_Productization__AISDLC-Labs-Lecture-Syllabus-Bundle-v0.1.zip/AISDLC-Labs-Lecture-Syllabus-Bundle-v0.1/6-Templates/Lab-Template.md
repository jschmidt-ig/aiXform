ChatGPT Folder > AI SDLC Course Productization > Lab-Template.md
# Lab Template

## Why this lab exists
## Scenario
## Starting state
## Constraints
## Deliverables
## Timebox
## Steps (with time estimates)
## Acceptance criteria
## Stretch goals
## Submission format
## Assessment (rubric mapping)
