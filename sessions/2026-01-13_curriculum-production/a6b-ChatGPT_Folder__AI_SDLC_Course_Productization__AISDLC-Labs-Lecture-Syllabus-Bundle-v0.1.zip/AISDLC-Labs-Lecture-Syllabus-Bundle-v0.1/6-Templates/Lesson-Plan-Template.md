ChatGPT Folder > AI SDLC Course Productization > Lesson-Plan-Template.md
# Lesson Plan Template (23-minute episode or 60-minute lecture)

- Title:
- Audience level:
- Timebox:
- Objective:
- Prerequisites:
- Constraints (security/tooling):
- Demo steps (scripted):
- Key takeaways:
- Common failure modes:
- “Do this next” action:
- References (internal only):
